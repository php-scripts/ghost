// js callbacks for index page
