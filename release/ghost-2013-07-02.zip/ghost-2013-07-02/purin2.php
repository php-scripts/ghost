<?php
    // override purin2 config file
    $pu_root = 'purin2/';
    $lurker_clear_password = 'do-not-commit-this';
?>